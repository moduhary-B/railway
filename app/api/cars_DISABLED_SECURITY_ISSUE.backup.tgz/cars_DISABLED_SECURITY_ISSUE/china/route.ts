import { NextRequest, NextResponse } from 'next/server';
import { spawn } from 'child_process';
import path from 'path';
import fs from 'fs';
import { logger } from '@/lib/logger';

// Функция для маппинга параметров сортировки
function mapSortParameter(sort?: string | null): string | undefined {
  if (!sort) return undefined;
  
  const sortMap: { [key: string]: string } = {
    'price_asc': 'low_price',
    'price_desc': 'high_price',
    'year_asc': 'old',
    'year_desc': 'new'
  };
  
  return sortMap[sort] || sort;
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ country: string }> }
) {
  const startTime = Date.now();
  
  try {
    const { searchParams } = new URL(request.url);
    
    // Подготовка параметров для парсера
    const filterParams = {
      brand: searchParams.get('brand') || undefined,
      model: searchParams.get('model') || undefined,
      year_from: searchParams.get('yearMin') ? parseInt(searchParams.get('yearMin')!) : undefined,
      year_to: searchParams.get('yearMax') ? parseInt(searchParams.get('yearMax')!) : undefined,
      price_from: searchParams.get('priceMin') ? parseInt(searchParams.get('priceMin')!) : undefined,
      price_to: searchParams.get('priceMax') ? parseInt(searchParams.get('priceMax')!) : undefined,
      mileage_from: searchParams.get('mileageMin') ? parseInt(searchParams.get('mileageMin')!) : undefined,
      mileage_to: searchParams.get('mileageMax') ? parseInt(searchParams.get('mileageMax')!) : undefined,
      eng_v_from: searchParams.get('engineVolumeMin') ? parseInt(searchParams.get('engineVolumeMin')!) : undefined,
      eng_v_to: searchParams.get('engineVolumeMax') ? parseInt(searchParams.get('engineVolumeMax')!) : undefined,
      body: searchParams.get('bodyType') || undefined,
      drive: searchParams.get('drive') || undefined,
      eng_type: searchParams.get('engType') || undefined,
      sort: mapSortParameter(searchParams.get('sort')),
      page: searchParams.get('page') ? parseInt(searchParams.get('page')!) : 1
    };

    logger.info(`Параметры фильтров для china:`, 'api', filterParams);

    // Путь к китайскому парсеру
    const parserDir = '/var/www/auto-pars/new.worldcar-ru';
    const parserPath = path.join(parserDir, 'china-catalog.py');

    logger.info(`Путь к парсеру: ${parserPath}`, 'api', { parserPath, parserDir });

    // Проверяем существование файла парсера
    if (!fs.existsSync(parserPath)) {
      logger.error(`Файл парсера не найден: ${parserPath}`, 'api', { parserPath });
      return NextResponse.json(
        { error: 'Parser not found' },
        { status: 500 }
      );
    }

    // Запуск парсера
    const result = await runParser(parserPath, parserDir, filterParams);

    const duration = Date.now() - startTime;
    
    logger.info(`Запрос успешно обработан`, 'api', {
      country: 'china',
      duration: `${duration}ms`,
      result: {
        carsCount: result.cars.length,
        totalCount: result.totalCount,
        parserUrl: result.parserUrl
      }
    });

    return NextResponse.json({
      success: true,
      data: result.cars,
      total: result.totalCount,
      pageSize: 20,
      totalPages: Math.ceil(result.totalCount / 20),
      filters: filterParams,
      duration: duration,
      country: 'china',
      parserUrl: result.parserUrl,
      parserInfo: {
        path: parserPath,
        directory: parserDir,
        baseUrl: 'https://new.worldcar.ru/china-used/'
      }
    });

  } catch (error) {
    const duration = Date.now() - startTime;
    
    logger.error(`Ошибка при обработке запроса`, 'api', {
      country: 'china',
      error: error instanceof Error ? error.message : 'Unknown error',
      duration: `${duration}ms`,
      stack: error instanceof Error ? error.stack : undefined
    });
    
    return NextResponse.json(
      { 
        error: 'Internal server error',
        details: error instanceof Error ? error.message : 'Unknown error',
        duration: duration
      },
      { status: 500 }
    );
  }
}

async function runParser(
  parserPath: string,
  parserDir: string,
  params: any
): Promise<{cars: any[], parserUrl: string, totalCount: number}> {
  return new Promise((resolve, reject) => {
    const startTime = Date.now();
    logger.info(`Запуск парсера для china`, 'parser', { parserPath, parserDir });
    
    // Фильтруем undefined значения
    const cleanParams = Object.fromEntries(
      Object.entries(params).filter(([_, value]) => value !== undefined)
    );

    logger.info(`Очищенные параметры для china:`, 'parser', cleanParams);

    const pythonProcess = spawn('python3', [parserPath], {
      cwd: parserDir,
      stdio: ['pipe', 'pipe', 'pipe']
    });

    let output = '';
    let errorOutput = '';
    let parserUrl = '';

    // Отправляем параметры в stdin
    const inputData = JSON.stringify(cleanParams);
    logger.info(`Отправка данных в парсер:`, 'parser', { inputData });
    
    pythonProcess.stdin.write(inputData);
    pythonProcess.stdin.end();

    pythonProcess.stdout.on('data', (data) => {
      const chunk = data.toString();
      output += chunk;
      logger.debug(`Парсер stdout:`, 'parser', { chunk });
      
      // Ищем URL в stdout
      const urlMatch = chunk.match(/Сформированная ссылка: (.+)/);
      if (urlMatch) {
        parserUrl = urlMatch[1];
        logger.info(`Найден URL парсера: ${parserUrl}`, 'parser', { parserUrl });
      }
    });

    pythonProcess.stderr.on('data', (data) => {
      const chunk = data.toString();
      errorOutput += chunk;
      logger.warn(`Парсер stderr:`, 'parser', { chunk });
    });

    pythonProcess.on('close', (code) => {
      const endTime = Date.now();
      const duration = endTime - startTime;
      logger.info(`Процесс парсера завершен с кодом ${code} за ${duration}ms`, 'parser', { code, duration });
      
      if (code === 0) {
        try {
          logger.debug(`Сырой вывод парсера (первые 500 символов):`, 'parser', { output: output.substring(0, 500) });
          
          // Очищаем вывод от лишнего текста перед JSON
          let cleanOutput = output;
          const jsonStartIndex = output.indexOf('{');
          if (jsonStartIndex !== -1) {
            cleanOutput = output.substring(jsonStartIndex);
            logger.debug(`JSON начинается с позиции ${jsonStartIndex}, длина очищенного вывода: ${cleanOutput.length}`, 'parser');
          } else {
            logger.warn(`JSON объект не найден в выводе`, 'parser');
          }
          
          const parserResult = JSON.parse(cleanOutput);
          logger.info(`Успешно распарсен результат парсера для china`, 'parser');
          
          // Извлекаем массив автомобилей и общее количество из результата
          let cars: any[] = [];
          let totalCount = 0;
          
          if (parserResult.results && Array.isArray(parserResult.results)) {
            cars = parserResult.results;
            totalCount = parserResult.total_count || 0;
          } else if (Array.isArray(parserResult)) {
            cars = parserResult;
            totalCount = 0;
          } else {
            logger.warn(`Массив автомобилей не найден в результате парсера`, 'parser');
            cars = [];
            totalCount = 0;
          }
          
          // Трансформируем данные в единый формат
          const transformedCars = cars.map((car: any, index: number) => {
            logger.debug(`Трансформация автомобиля ${index}:`, 'parser', { car });
            
            // Создаем объект только с реальными данными из парсера
            const transformedCar: any = {
              id: car.lot || car.id || `china-${index}`,
              name: (car.name || `${car.brand || 'Unknown'} ${car.model || ''}`.trim()), // Убираем комплектацию из названия
              brand: car.brand,
              model: car.model,
              price: car.price || car.price_val,
              mileage: car.mileage || car.mileage_val,
              fuelType: car.eng_type || car.fuel_type,
              transmission: car.transmission || car.kpp,
              bodyType: car.body || car.body_val,
              color: car.color,
              location: 'china',
              images: car.images || car.photos || car.photo || [],
              rating: car.rating,
              isHit: car.isHit,
              isNew: car.isNew,
              creditFrom: car.creditFrom,
              url: car.detail_url ? car.detail_url.replace('https://new.worldcar.ru', '') : car.url,
              // Дополнительные поля для китайского каталога
              power: car.power || car.power_val,
              drive: car.drive || car.drive_val,
              eng_type: car.eng_type,
              max_speed: car.max_speed,
              acceleration_0_100: car.acceleration_0_100,
              fuel_consumption: car.fuel_consumption,
              dimensions: car.dimensions,
              customs: car.customs,
              complectation: car.equipment,
              rate: car.rate,
              auctionDate: car.auction_date,
              sanctions: car.sanctions,
              serv: 3
            };
            
            // Добавляем engineVolume только если он есть в данных парсера
            if (car.engine_volume !== undefined && car.engine_volume !== null) {
              transformedCar.engineVolume = car.engine_volume;
            }
            
            // Добавляем год только если он есть в данных
            if (car.year) {
              transformedCar.year = car.year;
            }
            
            // Убираем undefined и null значения
            Object.keys(transformedCar).forEach(key => {
              if (transformedCar[key] === undefined || transformedCar[key] === null) {
                delete transformedCar[key];
              }
            });
            
            logger.debug(`Трансформированный автомобиль:`, 'parser', { transformedCar });
            return transformedCar;
          });
          
          logger.info(`Успешно трансформировано ${transformedCars.length} автомобилей из china`, 'parser');
          
          if (transformedCars.length > 0) {
            logger.debug(`Пример первого автомобиля:`, 'parser', { firstCar: transformedCars[0] });
            logger.debug(`Пример последнего автомобиля:`, 'parser', { lastCar: transformedCars[transformedCars.length - 1] });
          }
          
          resolve({
            cars: transformedCars,
            parserUrl: parserUrl || `URL не найден в выводе парсера`,
            totalCount: totalCount
          });
        } catch (parseError) {
          logger.error(`Ошибка парсинга результата парсера:`, 'parser', { 
            error: parseError instanceof Error ? parseError.message : 'Unknown error',
            rawOutput: output.substring(0, 1000)
          });
          reject(new Error(`Failed to parse parser output: ${parseError}`));
        }
      } else {
        logger.error(`Ошибка парсера с кодом ${code}:`, 'parser', { errorOutput });
        reject(new Error(`Parser failed with code ${code}: ${errorOutput}`));
      }
    });

    pythonProcess.on('error', (error) => {
      logger.error(`Не удалось запустить парсер:`, 'parser', { error: error.message });
      reject(error);
    });

    // Таймаут для парсера (60 секунд)
    setTimeout(() => {
      logger.error(`Таймаут парсера через 60 секунд`, 'parser');
      pythonProcess.kill();
      reject(new Error('Parser timeout'));
    }, 60000);
  });
} 