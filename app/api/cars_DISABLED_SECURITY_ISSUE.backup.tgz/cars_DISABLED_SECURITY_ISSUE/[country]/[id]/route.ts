import { NextRequest, NextResponse } from 'next/server';
import { spawn } from 'child_process';
import path from 'path';
import fs from 'fs';
import { logger } from '@/lib/logger';

export async function GET(
  request: NextRequest,
  { params }: { params: { country: string; id: string } }
) {
  const startTime = Date.now();
  
  try {
    const { country, id } = params;

    logger.apiRequest('GET', `/api/cars/${country}/${id}`, {
      country,
      id,
      searchParams: Object.fromEntries(request.nextUrl.searchParams.entries())
    });

    logger.info(`Запрос детальной информации для автомобиля ${id} из ${country}`, 'api', {
      country,
      id,
      searchParams: Object.fromEntries(request.nextUrl.searchParams.entries())
    });

    // Валидация страны
    const validCountries = ['japan', 'korea', 'china'];
    if (!validCountries.includes(country)) {
      logger.error(`Неверная страна: ${country}`, 'api', { country });
      return NextResponse.json(
        { error: 'Invalid country' },
        { status: 400 }
      );
    }

    // Определение пути к парсеру деталей в зависимости от страны
    let parserPath: string;
    let parserDir: string;

    switch (country) {
      case 'japan':
        parserDir = '/var/www/auto-pars/japan';
        parserPath = path.join(parserDir, 'J-priority-auto-detail.py');
        break;
      case 'korea':
        parserDir = '/var/www/auto-pars/korea';
        parserPath = path.join(parserDir, 'K-priority-auto-detail.py');
        break;
      case 'china':
        parserDir = '/var/www/auto-pars/new.worldcar-ru';
        parserPath = path.join(parserDir, 'china-detail.py');
        break;
      default:
        logger.error(`Неподдерживаемая страна: ${country}`, 'api', { country });
        return NextResponse.json(
          { error: 'Unsupported country' },
          { status: 400 }
        );
    }

    logger.info(`Путь к парсеру деталей: ${parserPath}`, 'api', { parserPath, parserDir });

    // Проверяем существование файла парсера
    if (!fs.existsSync(parserPath)) {
      logger.error(`Файл парсера деталей не найден: ${parserPath}`, 'api', { parserPath });
      return NextResponse.json(
        { error: 'Detail parser not found' },
        { status: 500 }
      );
    }

    // Параметры для получения детальной информации
    let detailParams: any;
    
    if (country === 'china') {
      // Для китайского каталога передаем URL напрямую
      let detailUrl = request.nextUrl.searchParams.get('detail_url');
      if (!detailUrl) {
        logger.error(`Отсутствует detail_url для китайского каталога`, 'api', { id });
        return NextResponse.json(
          { error: 'Detail URL required for China catalog' },
          { status: 400 }
        );
      }
      // Если URL относительный, добавляем базовый URL
      if (detailUrl.startsWith('/')) {
        detailUrl = 'https://new.worldcar.ru' + detailUrl;
      }
      detailParams = detailUrl; // Передаем URL как строку
    } else {
      // Для других каталогов передаем JSON параметры
      detailParams = {
        lot: id,
        detail_url: request.nextUrl.searchParams.get('detail_url') || undefined
      };
    }

    logger.info(`Параметры детальной информации для ${country}:`, 'api', { detailParams, country });

    // Запуск парсера деталей
    try {
      const carDetail = await runDetailParser(parserPath, parserDir, detailParams, country);

      const duration = Date.now() - startTime;

      logger.info(`Детальная информация успешно получена`, 'api', {
        country,
        id,
        duration: `${duration}ms`,
        hasData: !!carDetail
      });

      return NextResponse.json({
        success: true,
        data: carDetail,
        duration: duration,
        country: country
      });
    } catch (error) {
      const duration = Date.now() - startTime;
      logger.error(`Ошибка при получении детальной информации`, 'api', {
        country,
        id,
        error: error instanceof Error ? error.message : 'Unknown error',
        duration: `${duration}ms`
      });
      
      return NextResponse.json(
        { 
          error: 'Failed to get car details',
          details: error instanceof Error ? error.message : 'Unknown error',
          duration: duration
        },
        { status: 500 }
      );
    }

  } catch (error) {
    const duration = Date.now() - startTime;
    
    logger.error(`Ошибка при получении детальной информации`, 'api', {
      country: params.country,
      id: params.id,
      error: error instanceof Error ? error.message : 'Unknown error',
      duration: `${duration}ms`,
      stack: error instanceof Error ? error.stack : undefined
    });
    
    return NextResponse.json(
      { 
        error: 'Internal server error',
        details: error instanceof Error ? error.message : 'Unknown error',
        duration: duration
      },
      { status: 500 }
    );
  }
}

async function runDetailParser(
  parserPath: string,
  parserDir: string,
  params: any,
  country: string
): Promise<any> {
  return new Promise((resolve, reject) => {
    const startTime = Date.now();
    logger.info(`Запуск парсера деталей для ${country}`, 'parser', { parserPath, parserDir });
    
    // Фильтруем undefined значения
    let cleanParams: any;
    if (country === 'china') {
      // Для китайского каталога params уже является строкой URL
      cleanParams = params;
    } else {
      // Для других каталогов фильтруем undefined значения
      cleanParams = Object.fromEntries(
        Object.entries(params).filter(([_, value]) => value !== undefined)
      );
    }

    logger.info(`Очищенные параметры деталей для ${country}:`, 'parser', cleanParams);

    let pythonProcess: any;
    let output = '';
    let errorOutput = '';

    // Отправляем параметры в stdin
    let inputData: string;
    if (country === 'china') {
      // Для китайского каталога передаем URL как аргумент командной строки
      inputData = ''; // Пустая строка для stdin
      pythonProcess = spawn('python3', [parserPath, cleanParams.toString()], {
        cwd: parserDir,
        stdio: ['pipe', 'pipe', 'pipe']
      });
    } else {
      // Для других каталогов передаем JSON в stdin
      inputData = JSON.stringify(cleanParams);
      pythonProcess = spawn('python3', [parserPath], {
        cwd: parserDir,
        stdio: ['pipe', 'pipe', 'pipe']
      });
    }
    
    logger.info(`Отправка данных в парсер деталей:`, 'parser', { inputData, country });
    
    if (country !== 'china') {
      pythonProcess.stdin.write(inputData);
      pythonProcess.stdin.end();
    }

    pythonProcess.stdout.on('data', (data) => {
      const chunk = data.toString();
      output += chunk;
      logger.debug(`Парсер деталей stdout:`, 'parser', { chunk });
    });

    pythonProcess.stderr.on('data', (data) => {
      const chunk = data.toString();
      errorOutput += chunk;
      logger.warn(`Парсер деталей stderr:`, 'parser', { chunk });
    });

    pythonProcess.on('close', (code) => {
      const endTime = Date.now();
      const duration = endTime - startTime;
      logger.info(`Процесс парсера деталей завершен с кодом ${code} за ${duration}ms`, 'parser', { code, duration });
      
      if (code === 0) {
        try {
          logger.debug(`Сырой вывод парсера деталей (первые 500 символов):`, 'parser', { output: output.substring(0, 500) });
          
          // Очищаем вывод от лишнего текста перед JSON
          let cleanOutput = output;
          const jsonStartIndex = output.indexOf('{');
          if (jsonStartIndex !== -1) {
            cleanOutput = output.substring(jsonStartIndex);
            logger.debug(`JSON начинается с позиции ${jsonStartIndex}, длина очищенного вывода: ${cleanOutput.length}`, 'parser');
          } else {
            logger.warn(`JSON объект не найден в выводе парсера деталей`, 'parser');
          }
          
          const parserResult = JSON.parse(cleanOutput);
          logger.info(`Успешно распарсен результат парсера деталей для ${country}`, 'parser');
          
          // Извлекаем данные из результата
          let carDetail: any = {};
          if (parserResult.results && Array.isArray(parserResult.results) && parserResult.results.length > 0) {
            carDetail = parserResult.results[0];
          } else if (parserResult.car) {
            carDetail = parserResult.car;
          } else {
            carDetail = parserResult;
          }
          
          logger.info(`Детальная информация автомобиля получена`, 'parser', {
            hasData: !!carDetail,
            carId: carDetail.id || carDetail.lot
          });
          
          resolve(carDetail);
        } catch (parseError) {
          logger.error(`Ошибка парсинга результата парсера деталей:`, 'parser', { 
            error: parseError instanceof Error ? parseError.message : 'Unknown error',
            rawOutput: output.substring(0, 1000)
          });
          reject(new Error(`Failed to parse detail parser output: ${parseError}`));
        }
      } else {
        logger.error(`Ошибка парсера деталей с кодом ${code}:`, 'parser', { errorOutput });
        reject(new Error(`Detail parser failed with code ${code}: ${errorOutput}`));
      }
    });

    pythonProcess.on('error', (error) => {
      logger.error(`Не удалось запустить парсер деталей:`, 'parser', { error: error.message, country });
      reject(error);
    });

    // Таймаут для парсера (30 секунд)
    setTimeout(() => {
      logger.error(`Таймаут парсера деталей через 30 секунд`, 'parser');
      pythonProcess.kill();
      reject(new Error('Detail parser timeout'));
    }, 30000);
  });
} 