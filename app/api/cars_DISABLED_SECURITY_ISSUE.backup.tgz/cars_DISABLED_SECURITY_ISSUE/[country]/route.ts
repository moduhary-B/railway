import { NextRequest, NextResponse } from 'next/server';
import { spawn } from 'child_process';
import path from 'path';
import fs from 'fs';
import { logger } from '@/lib/logger';

// Функция для преобразования параметров сортировки
function mapSortParameter(sort?: string | null): string | undefined {
  if (!sort) return undefined;
  
  const sortMapping: { [key: string]: string } = {
    'price_asc': 'PRICE--ASC',
    'price_desc': 'PRICE--DESC',
    'year_asc': 'YEAR--ASC',
    'year_desc': 'YEAR--DESC',
    'mileage_asc': 'MILEAGE--ASC',
    'mileage_desc': 'MILEAGE--DESC'
  };
  
  return sortMapping[sort] || undefined;
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ country: string }> }
) {
  const startTime = Date.now();
  const { searchParams } = new URL(request.url);
  const { country } = await params;

  try {
    logger.apiRequest('GET', `/api/cars/${country}`, {
      country,
      searchParams: Object.fromEntries(searchParams.entries())
    });

    logger.info(`Начало обработки запроса для страны: ${country}`, 'api', {
      country,
      searchParams: Object.fromEntries(searchParams.entries())
    });

    // Валидация страны
    const validCountries = ['japan', 'korea', 'china'];
    if (!validCountries.includes(country)) {
      logger.error(`Неверная страна: ${country}`, 'api', { country });
      return NextResponse.json(
        { error: 'Invalid country' },
        { status: 400 }
      );
    }

    // Подготовка параметров для парсера
    const filterParams = {
      marka: searchParams.get('brand') || undefined,
      model: searchParams.get('model') || undefined,
      year_from: searchParams.get('yearMin') ? parseInt(searchParams.get('yearMin')!) : undefined,
      year_to: searchParams.get('yearMax') ? parseInt(searchParams.get('yearMax')!) : undefined,
      price_from: searchParams.get('priceMin') ? parseInt(searchParams.get('priceMin')!) : undefined,
      price_to: searchParams.get('priceMax') ? parseInt(searchParams.get('priceMax')!) : undefined,
      mileage_from: searchParams.get('mileageMin') ? parseInt(searchParams.get('mileageMin')!) : undefined,
      mileage_to: searchParams.get('mileageMax') ? parseInt(searchParams.get('mileageMax')!) : undefined,
      eng_v_from: searchParams.get('engineVolumeMin') ? parseInt(searchParams.get('engineVolumeMin')!) : undefined,
      eng_v_to: searchParams.get('engineVolumeMax') ? parseInt(searchParams.get('engineVolumeMax')!) : undefined,
      power_from: searchParams.get('powerMin') ? parseInt(searchParams.get('powerMin')!) : undefined,
      power_to: searchParams.get('powerMax') ? parseInt(searchParams.get('powerMax')!) : undefined,
      kuzov_manual: searchParams.get('bodyType') || undefined,
      rate: searchParams.get('rate') || undefined,
      sort: mapSortParameter(searchParams.get('sort')),
      page: searchParams.get('page') ? parseInt(searchParams.get('page')!) : 1
    };

    logger.info(`Параметры фильтров для ${country}:`, 'api', filterParams);

    // Определение пути к парсеру в зависимости от страны
    let parserPath: string;
    let parserDir: string;

    switch (country) {
      case 'japan':
        parserDir = '/var/www/auto-pars/japan';
        parserPath = path.join(parserDir, 'J-priority-auto.py');
        break;
      case 'korea':
        parserDir = '/var/www/auto-pars/korea';
        parserPath = path.join(parserDir, 'K-priority-auto.py');
        break;
      case 'china':
        parserDir = '/var/www/auto-pars/batareyka125';
        parserPath = path.join(parserDir, 'batareyka125_catalog.py');
        break;
      default:
        logger.error(`Неподдерживаемая страна: ${country}`, 'api', { country });
        return NextResponse.json(
          { error: 'Unsupported country' },
          { status: 400 }
        );
    }

    logger.info(`Путь к парсеру: ${parserPath}`, 'api', { parserPath, parserDir });

    // Проверяем существование файла парсера
    if (!fs.existsSync(parserPath)) {
      logger.error(`Файл парсера не найден: ${parserPath}`, 'api', { parserPath });
      return NextResponse.json(
        { error: 'Parser not found' },
        { status: 500 }
      );
    }

    // Запуск парсера
    const result = await runParser(parserPath, parserDir, filterParams, country);

    const duration = Date.now() - startTime;
    
    logger.info(`Запрос успешно обработан`, 'api', {
      country,
      duration: `${duration}ms`,
      result: {
        carsCount: result.cars.length,
        totalCount: result.totalCount,
        parserUrl: result.parserUrl
      }
    });

    // Определяем размер страницы в зависимости от страны
    const getPageSize = (country: string): number => {
      switch (country) {
        case 'japan': return 60;
        case 'korea': return 24;
        case 'china': return 20;
        default: return 24;
      }
    };

    const pageSize = getPageSize(country);

    return NextResponse.json({
      success: true,
      data: result.cars,
      total: result.totalCount,
      pageSize: pageSize,
      totalPages: Math.ceil(result.totalCount / pageSize),
      filters: filterParams,
      duration: duration,
      country: country,
      parserUrl: result.parserUrl,
      parserInfo: {
        path: parserPath,
        directory: parserDir,
        baseUrl: getBaseUrl(country)
      }
    });

  } catch (error) {
    const duration = Date.now() - startTime;
    
    logger.error(`Ошибка при обработке запроса`, 'api', {
      country: (await params).country,
      error: error instanceof Error ? error.message : 'Unknown error',
      duration: `${duration}ms`,
      stack: error instanceof Error ? error.stack : undefined
    });
    
    return NextResponse.json(
      { 
        error: 'Internal server error',
        details: error instanceof Error ? error.message : 'Unknown error',
        duration: duration
      },
      { status: 500 }
    );
  }
}

// Функция для получения базового URL парсера
function getBaseUrl(country: string): string {
  switch (country) {
    case 'japan':
      return 'https://priority-auto.ru/auto-from-japan/';
    case 'korea':
      return 'https://priority-auto.ru/auto-from-korea/';
    case 'china':
      return 'https://batareyka125.ru/';
    default:
      return '';
  }
}

async function runParser(
  parserPath: string,
  parserDir: string,
  params: any,
  country: string
): Promise<{cars: any[], parserUrl: string, totalCount: number}> {
  return new Promise((resolve, reject) => {
    const startTime = Date.now();
    logger.info(`Запуск парсера для ${country}`, 'parser', { parserPath, parserDir });
    
    // Фильтруем undefined значения
    const cleanParams = Object.fromEntries(
      Object.entries(params).filter(([_, value]) => value !== undefined)
    );

    logger.info(`Очищенные параметры для ${country}:`, 'parser', cleanParams);

    const pythonProcess = spawn('python3', [parserPath], {
      cwd: parserDir,
      stdio: ['pipe', 'pipe', 'pipe']
    });

    let output = '';
    let errorOutput = '';
    let parserUrl = '';

    // Отправляем параметры в stdin
    const inputData = JSON.stringify(cleanParams);
    logger.info(`Отправка данных в парсер:`, 'parser', { inputData });
    
    pythonProcess.stdin.write(inputData);
    pythonProcess.stdin.end();

    pythonProcess.stdout.on('data', (data) => {
      const chunk = data.toString();
      output += chunk;
      logger.debug(`Парсер stdout:`, 'parser', { chunk });
      
      // Ищем URL в stdout
      const urlMatch = chunk.match(/Сформированная ссылка: (.+)/);
      if (urlMatch) {
        parserUrl = urlMatch[1];
        logger.info(`Найден URL парсера: ${parserUrl}`, 'parser', { parserUrl });
      }
    });

    pythonProcess.stderr.on('data', (data) => {
      const chunk = data.toString();
      errorOutput += chunk;
      logger.warn(`Парсер stderr:`, 'parser', { chunk });
    });

    pythonProcess.on('close', (code) => {
      const endTime = Date.now();
      const duration = endTime - startTime;
      logger.info(`Процесс парсера завершен с кодом ${code} за ${duration}ms`, 'parser', { code, duration });
      
      if (code === 0) {
        try {
          logger.debug(`Сырой вывод парсера (первые 500 символов):`, 'parser', { output: output.substring(0, 500) });
          
          // Очищаем вывод от лишнего текста перед JSON
          let cleanOutput = output;
          const jsonStartIndex = output.indexOf('{');
          if (jsonStartIndex !== -1) {
            cleanOutput = output.substring(jsonStartIndex);
            logger.debug(`JSON начинается с позиции ${jsonStartIndex}, длина очищенного вывода: ${cleanOutput.length}`, 'parser');
          } else {
            logger.warn(`JSON объект не найден в выводе`, 'parser');
          }
          
          const parserResult = JSON.parse(cleanOutput);
          logger.info(`Успешно распарсен результат парсера для ${country}`, 'parser');
          
          // Извлекаем общее количество автомобилей
          const totalCount = parserResult.total_count || 0;
          logger.info(`Общее количество автомобилей: ${totalCount}`, 'parser', { totalCount });
          
          // Извлекаем массив автомобилей из результата
          let cars: any[] = [];
          if (parserResult.results && Array.isArray(parserResult.results)) {
            cars = parserResult.results;
          } else if (Array.isArray(parserResult)) {
            cars = parserResult;
          } else {
            logger.warn(`Массив автомобилей не найден в результате парсера`, 'parser');
            cars = [];
          }
          
          // Трансформируем данные в единый формат
          const transformedCars = cars.map((car: any, index: number) => {
            logger.debug(`Трансформация автомобиля ${index}:`, 'parser', { car });
            
            // Создаем объект только с реальными данными из парсера
            const transformedCar: any = {
              id: car.lot || car.id || `${country}-${index}`,
              name: (car.name || `${car.brand || 'Unknown'} ${car.model || ''}`.trim()) + (car.complectation ? ` ${car.complectation}` : ''),
              brand: car.brand,
              model: car.model,
              price: car.price || car.price_val,
              mileage: car.mileage || car.mileage_val,
              engineVolume: car.engine_volume || car.volume_val,
              fuelType: car.eng_type || car.fuel_type,
              transmission: car.kpp_type || car.transmission,
              bodyType: car.body || car.body_val,
              color: car.color,
              location: country,
              images: car.photos || car.images || car.photo || [],
              rating: car.rating,
              isHit: car.isHit,
              isNew: car.isNew,
              creditFrom: car.creditFrom,
              url: car.detail_url || car.url,
              // Дополнительные поля
              power: car.power || car.power_val,
              drive: car.drive || car.drive_val,
              complectation: car.complectation,
              rate: car.rate,
              auctionDate: car.auction_date,
              sanctions: car.sanctions,
              serv: car.serv
            };
            
            // Добавляем год только если он есть в данных
            if (car.year) {
              transformedCar.year = car.year;
            }
            
            // Убираем undefined и null значения
            Object.keys(transformedCar).forEach(key => {
              if (transformedCar[key] === undefined || transformedCar[key] === null) {
                delete transformedCar[key];
              }
            });
            
            logger.debug(`Трансформированный автомобиль:`, 'parser', { transformedCar });
            return transformedCar;
          });
          
          logger.info(`Успешно трансформировано ${transformedCars.length} автомобилей из ${country}`, 'parser');
          
          if (transformedCars.length > 0) {
            logger.debug(`Пример первого автомобиля:`, 'parser', { firstCar: transformedCars[0] });
            logger.debug(`Пример последнего автомобиля:`, 'parser', { lastCar: transformedCars[transformedCars.length - 1] });
          }
          
          resolve({
            cars: transformedCars,
            parserUrl: parserUrl || `URL не найден в выводе парсера`,
            totalCount: totalCount
          });
        } catch (parseError) {
          logger.error(`Ошибка парсинга результата парсера:`, 'parser', { 
            error: parseError instanceof Error ? parseError.message : 'Unknown error',
            rawOutput: output.substring(0, 1000)
          });
          reject(new Error(`Failed to parse parser output: ${parseError}`));
        }
      } else {
        logger.error(`Ошибка парсера с кодом ${code}:`, 'parser', { errorOutput });
        reject(new Error(`Parser failed with code ${code}: ${errorOutput}`));
      }
    });

    pythonProcess.on('error', (error) => {
      logger.error(`Не удалось запустить парсер:`, 'parser', { error: error.message });
      reject(error);
    });

    // Таймаут для парсера (60 секунд)
    setTimeout(() => {
      logger.error(`Таймаут парсера через 60 секунд`, 'parser');
      pythonProcess.kill();
      reject(new Error('Parser timeout'));
    }, 60000);
  });
} 